#' Rdataanalysis.
#'
#' @name Rdataanalysis
#' @docType package
NULL
